//
//  GameScene.swift
//  scroolgaem
//
//  Created by Vaughan Webb on 21/10/19.
//  DogeCoin wallet: 196363514
//  Copyright © 2019 Vaughan Webb. All rights reserved.
//

import SpriteKit

extension Double
{
    var toString: String
    {
        return NSNumber(value: self).stringValue
    }
    
}

extension CGPoint
{
    func distance(point: CGPoint) -> CGFloat
    {
        return abs(CGFloat(hypotf(Float(point.x - x), Float(point.y - y))))
    }
}
extension Float
{
    var f: CGFloat { return CGFloat(self) }
}

class GameScene1: SKScene, SKPhysicsContactDelegate
{
    var label = SKLabelNode()
    var label2 = SKLabelNode()
    let Node1 = SKShapeNode(circleOfRadius: 32)
    let temp = SKNode()
    let Boundry = SKSpriteNode()
    let roof = SKSpriteNode()
    var node2 = SKShapeNode()
    var tilemap: SKSpriteNode!
    var tileMap: SKNode!
    let light = SKLightNode()
    let rectangle1 = SKSpriteNode()
    let rectangle2 = SKSpriteNode()
    let rectangle3 = SKSpriteNode()
    let rectangle4 = SKSpriteNode()
    var timerR1 = 0.0;
    var timerR2 = 0.0;
    var timerR3 = 0.0;
    var timerR4 = 0.0;
    var R1rand = 0.0;
    var R2rand = 0.0;
    var R3rand = 0.0;
    var R4rand = 0.0;
    var pushup = false
    var kill = false
    var gamestate = 0 //0 playing, 1 win, 2 loss
    var cameraNode: SKCameraNode!
    var timer = 0.0;
    
    var Delta = 0.0
    var CurrentTime = 0.0
    var LastTime = 0.0
    var lastupdatetime: CFTimeInterval = 0.0
    var starttime = 0.0

    
    enum CategoryBitMask
    {
        static let Node1: UInt32 = 0b0001
        static let obsticle: UInt32 = 0b0100
        static let boundry: UInt32 = 0b1000
    }
    
    override func didMove(to view: SKView)
    {
        createLight()
        CreateTileMap()
        
        Boundry.name = "ground"
        Boundry.color = UIColor.green
        Boundry.size = CGSize(width: self.frame.width, height: 10)
        Boundry.position = CGPoint(x: self.frame.midX, y: self.frame.minY)
        Boundry.physicsBody = SKPhysicsBody(rectangleOf: Boundry.size)
        Boundry.physicsBody?.isDynamic = false
        Boundry.physicsBody?.categoryBitMask = CategoryBitMask.boundry
        addChild(Boundry)
        
        roof.name = "roof"
        roof.color = UIColor.green
        roof.size = CGSize(width: self.frame.width - 10, height: 10)
        roof.position = CGPoint(x: Boundry.position.x, y: Boundry.position.y + 2000)
        roof.physicsBody = SKPhysicsBody(rectangleOf: roof.size)
        roof.physicsBody?.isDynamic = false
        roof.physicsBody?.categoryBitMask = CategoryBitMask.boundry
        addChild(roof)
        

        self.physicsWorld.contactDelegate = self
        
        createNode1()
        createobsticle(1)
        createobsticle(2)
        createobsticle(3)
        createobsticle(4)

        Createcam()
        createlabel()
        
        self.listener = Node1
        Audio()
        
        starttime = CACurrentMediaTime()
 
    }
    
    override func update(_ seconds: CFTimeInterval)
    {
        
        if (gamestate == 0)
        {
            cameraNode.run(SKAction.move(to: CGPoint(x: self.frame.midX , y: Node1.position.y), duration: 0.5))
            
            CurrentTime = CACurrentMediaTime() - starttime
            Delta = CurrentTime - LastTime
            LastTime = CurrentTime
            
            //timer = timer + (seconds / 20000000)
            //let formatter = NumberFormatter()
            //formatter.maximumFractionDigits = 3
            //formatter.minimumFractionDigits = 3
            //timerR1 = timerR1 + (seconds / 20000000);
            //timerR2 = timerR2 + (seconds / 20000000);
            //timerR3 = timerR3 + (seconds / 20000000);
            //timerR4 = timerR4 + (seconds / 20000000);
            
            timer = timer + Delta
            let formatter = NumberFormatter()
            formatter.maximumFractionDigits = 3
            formatter.minimumFractionDigits = 3
            timerR1 = timerR1 + Delta
            timerR2 = timerR2 + Delta
            timerR3 = timerR3 + Delta
            timerR4 = timerR4 + Delta
            
            
            
            //rand from 1-4
            moveObsticles()
            
            let text = formatter.string(from: NSNumber(value: timer)) //"\(timer)"
            label.text = text
            if (pushup == true)
            {
                Node1.physicsBody?.velocity = CGVector(dx: 0, dy: 750)
            }
            else
            {
                if((Node1.physicsBody?.velocity.dy)! > CGFloat(0.0))
                {
                    Node1.physicsBody?.velocity.dy = (Node1.physicsBody?.velocity.dy)! - CGFloat(500)
                }
            }
            
        }
        else
        {
            let formatter = NumberFormatter()
            formatter.maximumFractionDigits = 3
            formatter.minimumFractionDigits = 3
            let timertext = formatter.string(from: NSNumber(value: timer))

            if (gamestate == 1)
            {
                //celebrade
                label.text = "congratulations you won"
                label2.text = "in " +  timertext! + " seconds!"

            }
            if (gamestate == 2)
            {
                label.text = "congratulations you died"
                label2.text =  "in " +  timertext! + " seconds!"
                Node1.physicsBody?.velocity = CGVector(dx: -1200, dy: 0)
            }
        }

    }
    
    func moveObsticles()
    {
        if (timerR1 > R1rand)
        {
            timerR1 = 0.0
            R1rand = Double.random(in: 3 ... 5)
            rectangle1.run(SKAction.sequence([SKAction.move(to: CGPoint(x: Boundry.position.x, y: Boundry.position.y + 1600), duration: 1.0), (SKAction.move(to: CGPoint(x: Boundry.position.x + 300, y: Boundry.position.y + 1600), duration: 0.7))]))
        }
        if (timerR2 > R2rand)
        {
            timerR2 = 0.0
            R2rand = Double.random(in: 3 ... 5)
            rectangle2.run(SKAction.sequence([SKAction.move(to: CGPoint(x: Boundry.position.x, y: Boundry.position.y + 1200), duration: 1.0), (SKAction.move(to: CGPoint(x: Boundry.position.x + 300, y: Boundry.position.y + 1200), duration: 0.7))]))
        }
        if (timerR3 > R3rand)
        {
            timerR3 = 0.0
            R3rand = Double.random(in: 3 ... 5)
            rectangle3.run(SKAction.sequence([SKAction.move(to: CGPoint(x: Boundry.position.x, y: Boundry.position.y + 800), duration: 1.0), (SKAction.move(to: CGPoint(x: Boundry.position.x + 300, y: Boundry.position.y + 800), duration: 0.7))]))
        }
        if (timerR4 > R4rand)
        {
            timerR4 = 0.0
            R4rand = Double.random(in: 3 ... 5)
            rectangle4.run(SKAction.sequence([SKAction.move(to: CGPoint(x: Boundry.position.x, y: Boundry.position.y + 400), duration: 1.0), (SKAction.move(to: CGPoint(x: Boundry.position.x + 300, y: Boundry.position.y + 400), duration: 0.7))]))
        }
        
        
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?)
    {
        if (gamestate == 0)
        {
            
            pushup = true

        }
        else
        {
            let newScene = MainMenu(size: (self.view?.bounds.size)!)
            let transition = SKTransition.reveal(with: .down, duration: 2)
            self.view?.presentScene(newScene, transition: transition)
            
            transition.pausesOutgoingScene = false
            transition.pausesIncomingScene = false
            
        }
    }
    
    override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?)
    {
        pushup = false
    }
    
    func Createcam()
    {
        cameraNode = SKCameraNode()
        cameraNode.setScale(1)
        cameraNode.position = CGPoint(x: self.frame.midX, y: self.frame.midY)
        self.camera = cameraNode
        self.addChild(cameraNode)
        
    }
    
    func didBegin(_ contact: SKPhysicsContact)
    {
        if (gamestate == 0)
        {
            if (contact.bodyA.categoryBitMask | contact.bodyB.categoryBitMask == CategoryBitMask.Node1 | CategoryBitMask.obsticle)
            {
                print("node 1")
                kill = true
                gamestate = 2 //0 playing, 1 win, 2 loss
            }
            if (contact.bodyA.categoryBitMask | contact.bodyB.categoryBitMask == CategoryBitMask.Node1 | CategoryBitMask.boundry)
            {
                if ( distance(vector2( Float(Node1.position.x), Float(Node1.position.y )) , vector2( Float(roof.position.x ),Float( roof.position.y ))) < 500 )
                {
                    gamestate = 1
                }
            }
        }

    }
    
    
    func createNode1()
    {
        Node1.name = "one"
        Node1.fillColor = UIColor.blue
        Node1.position = CGPoint(x: self.frame.midX, y: self.frame.minY + 11)
        Node1.physicsBody = SKPhysicsBody(circleOfRadius: Node1.frame.width/2)
        Node1.physicsBody?.categoryBitMask = CategoryBitMask.Node1
        Node1.physicsBody?.contactTestBitMask = CategoryBitMask.boundry | CategoryBitMask.obsticle
        Node1.physicsBody?.collisionBitMask = CategoryBitMask.boundry | CategoryBitMask.obsticle
        
        addChild(Node1)
        
        node2 = SKShapeNode(rectOf: CGSize(width: 64, height: 64))
        node2.fillColor = SKColor.white
        node2.fillTexture = SKTexture(imageNamed: "doge")
        Node1.addChild(node2)
        
    }
    
    
    func createobsticle(_ number: Int)
    {
        if (number == 1)
        {
            rectangle1.name = "obsicle"
            rectangle1.color = UIColor.red
            rectangle1.size = CGSize(width: self.frame.width - 10, height: 10)
            rectangle1.position = CGPoint(x: Boundry.position.x + 300, y: Boundry.position.y + 1600)
            rectangle1.physicsBody = SKPhysicsBody(rectangleOf: rectangle1.size)
            rectangle1.physicsBody?.isDynamic = false
            rectangle1.physicsBody?.categoryBitMask = CategoryBitMask.obsticle
            addChild(rectangle1)
        }
        
        if (number == 2)
        {
            rectangle2.name = "obsicle"
            rectangle2.color = UIColor.red
            rectangle2.size = CGSize(width: self.frame.width - 10, height: 10)
            rectangle2.position = CGPoint(x: Boundry.position.x + 300, y: Boundry.position.y + 1200)
            rectangle2.physicsBody = SKPhysicsBody(rectangleOf: rectangle2.size)
            rectangle2.physicsBody?.isDynamic = false
            rectangle2.physicsBody?.categoryBitMask = CategoryBitMask.obsticle
            addChild(rectangle2)
        }
        
        if (number == 3)
        {
            rectangle3.name = "obsicle"
            rectangle3.color = UIColor.red
            rectangle3.size = CGSize(width: self.frame.width - 10, height: 10)
            rectangle3.position = CGPoint(x: Boundry.position.x + 300, y: Boundry.position.y + 800)
            rectangle3.physicsBody = SKPhysicsBody(rectangleOf: rectangle3.size)
            rectangle3.physicsBody?.isDynamic = false
            rectangle3.physicsBody?.categoryBitMask = CategoryBitMask.obsticle
            addChild(rectangle3)
        }
        
        if (number == 4)
        {
            rectangle4.name = "obsicle"
            rectangle4.color = UIColor.red
            rectangle4.size = CGSize(width: self.frame.width - 10, height: 10)
            rectangle4.position = CGPoint(x: Boundry.position.x + 300, y: Boundry.position.y + 400)
            rectangle4.physicsBody = SKPhysicsBody(rectangleOf: rectangle4.size)
            rectangle4.physicsBody?.isDynamic = false
            rectangle4.physicsBody?.categoryBitMask = CategoryBitMask.obsticle
            addChild(rectangle4)
        }

    }
    
    func createlabel()
    {
        label = SKLabelNode()
        label.text = "this gets replaced with time"
        label.fontSize = 32.0
        if (UserDefaults.standard.integer(forKey: "Lighting") == 0) //lighting on (default)
        {
            label.fontColor = UIColor.white
        }
        else // lighting off
        {
            label.fontColor = UIColor.black
        }
        label.position = CGPoint(x:  0, y:  300 * cameraNode.yScale)
        cameraNode.addChild(label)
        
        
        
        label2 = SKLabelNode()
        label2.text = ""
        label2.fontSize = 32.0
        if (UserDefaults.standard.integer(forKey: "Lighting") == 0) //lighting on (default)
        {
            label2.fontColor = UIColor.white
        }
        else // lighting off
        {
            label2.fontColor = UIColor.black
        }
        label2.position = CGPoint(x: 0, y:  250 * cameraNode.yScale)
        cameraNode.addChild(label2)
    }
    
    func CreateTileMap()
    {
        tileMap = SKNode()
        addChild(tileMap)
        tileMap.setScale(CGFloat(1.0))
        
        let tileSet = SKTileSet(named: "bgTile")
        let tileSize = CGSize(width: 256, height: 256)
        let rockTile = tileSet?.tileGroups.first { $0.name == "Cobblestone" }
        
        let backgroundLayer = SKTileMapNode(tileSet: tileSet!, columns: 4 , rows: 20 , tileSize: tileSize)
        backgroundLayer.fill(with: rockTile)
        
        backgroundLayer.zPosition = -1
        
        if (UserDefaults.standard.integer(forKey: "Lighting") == 0) //lighting on (default)
        {
            backgroundLayer.lightingBitMask = 1

        }
        else // lighting off
        {
        }
        tileMap.addChild(backgroundLayer)

    }
    
    func Audio()
    {
        let audioNode = SKAudioNode(fileNamed: "foxxy dekay & 4649nadeshiko - 37564.mp3")
        audioNode.autoplayLooped = true
        self.addChild(audioNode)
        audioNode.run(SKAction.play())
        
    }
    
    func createLight()
    {
        light.categoryBitMask = 1
        light.falloff = 0.1
        light.ambientColor = UIColor(red: 0.1, green: 0.1, blue: 0.1, alpha: 1.0)
        light.lightColor = UIColor(red: 0.9, green: 0.9, blue: 0.9, alpha: 1.0)
        light.shadowColor = UIColor(red: 0.0, green: 0.0, blue: 0.0, alpha: 0.2)
        light.position = CGPoint(x: 0, y: 0)
        self.addChild(light)
        
    }
}

class GameScene2: SKScene, SKPhysicsContactDelegate
{
    var label = SKLabelNode()
    var label2 = SKLabelNode()
    let Node1 = SKShapeNode(circleOfRadius: 32)
    let temp = SKNode()
    let Boundry = SKSpriteNode()
    let roof = SKSpriteNode()
    var node2 = SKShapeNode()
    var tilemap: SKSpriteNode!
    var tileMap: SKNode!
    let light = SKLightNode()
    let rectangle1 = SKSpriteNode()
    let rectangle2 = SKSpriteNode()
    let rectangle3 = SKSpriteNode()
    let rectangle4 = SKSpriteNode()
    var timerR1 = 0.0;
    var timerR2 = 0.0;
    var timerR3 = 0.0;
    var timerR4 = 0.0;
    var R1rand = 0.0;
    var R2rand = 0.0;
    var R3rand = 0.0;
    var R4rand = 0.0;
    var pushup = false
    var kill = false
    var gamestate = 0 //0 playing, 1 win, 2 loss
    var cameraNode: SKCameraNode!
    var timer = 0.0;
    
    var Delta = 0.0
    var CurrentTime = 0.0
    var LastTime = 0.0
    var lastupdatetime: CFTimeInterval = 0.0
    var starttime = 0.0
    
    
    enum CategoryBitMask
    {
        static let Node1: UInt32 = 0b0001
        static let obsticle: UInt32 = 0b0100
        static let boundry: UInt32 = 0b1000
    }
    
    override func didMove(to view: SKView)
    {
        createLight()
        CreateTileMap()
        
        Boundry.name = "ground"
        Boundry.color = UIColor.green
        Boundry.size = CGSize(width: self.frame.width, height: 10)
        Boundry.position = CGPoint(x: self.frame.midX, y: self.frame.minY)
        Boundry.physicsBody = SKPhysicsBody(rectangleOf: Boundry.size)
        Boundry.physicsBody?.isDynamic = false
        Boundry.physicsBody?.categoryBitMask = CategoryBitMask.boundry
        addChild(Boundry)
        
        roof.name = "roof"
        roof.color = UIColor.green
        roof.size = CGSize(width: self.frame.width - 10, height: 10)
        roof.position = CGPoint(x: Boundry.position.x, y: Boundry.position.y + 2000)
        roof.physicsBody = SKPhysicsBody(rectangleOf: roof.size)
        roof.physicsBody?.isDynamic = false
        roof.physicsBody?.categoryBitMask = CategoryBitMask.boundry
        addChild(roof)
        
        
        self.physicsWorld.contactDelegate = self
        
        createNode1()
        createobsticle(1)
        createobsticle(2)
        createobsticle(3)
        createobsticle(4)
        
        Createcam()
        createlabel()
        
        self.listener = Node1
        Audio()
        
        starttime = CACurrentMediaTime()
        
    }
    
    override func update(_ seconds: CFTimeInterval)
    {
        
        if (gamestate == 0)
        {
            cameraNode.run(SKAction.move(to: CGPoint(x: self.frame.midX , y: Node1.position.y), duration: 0.5))
            
            CurrentTime = CACurrentMediaTime() - starttime
            Delta = CurrentTime - LastTime
            LastTime = CurrentTime
            
            timer = timer + Delta
            let formatter = NumberFormatter()
            formatter.maximumFractionDigits = 3
            formatter.minimumFractionDigits = 3
            timerR1 = timerR1 + Delta
            timerR2 = timerR2 + Delta
            timerR3 = timerR3 + Delta
            timerR4 = timerR4 + Delta
            
            
            
            //rand from 1-4
            moveObsticles()
            
            let text = formatter.string(from: NSNumber(value: timer)) //"\(timer)"
            label.text = text
            if (pushup == true)
            {
                Node1.physicsBody?.velocity = CGVector(dx: 0, dy: 750)
            }
            else
            {
                if((Node1.physicsBody?.velocity.dy)! > CGFloat(0.0))
                {
                    Node1.physicsBody?.velocity.dy = (Node1.physicsBody?.velocity.dy)! - CGFloat(500)
                }
            }
            
        }
        else
        {
            let formatter = NumberFormatter()
            formatter.maximumFractionDigits = 3
            formatter.minimumFractionDigits = 3
            let timertext = formatter.string(from: NSNumber(value: timer))
            
            if (gamestate == 1)
            {
                //celebrade
                label.text = "congratulations you won"
                label2.text = "in " +  timertext! + " seconds!"
                
            }
            if (gamestate == 2)
            {
                label.text = "congratulations you died"
                label2.text =  "in " +  timertext! + " seconds!"
                Node1.physicsBody?.velocity = CGVector(dx: -1200, dy: 0)
            }
        }
        
    }
    
    func moveObsticles()
    {
        if (timerR1 > R1rand)
        {
            timerR1 = 0.0
            R1rand = Double.random(in: 1 ... 5)
            rectangle1.run(SKAction.rotate(byAngle: 3.145926, duration: 0.7))
            rectangle1.run(SKAction.sequence([SKAction.move(to: CGPoint(x: Boundry.position.x, y: Boundry.position.y + 1600), duration: 1.0), (SKAction.move(to: CGPoint(x: Boundry.position.x + 300, y: Boundry.position.y + 1600), duration: 0.7))]))
        }
        if (timerR2 > R2rand)
        {
            timerR2 = 0.0
            R2rand = Double.random(in: 1 ... 5)
            rectangle2.run(SKAction.sequence([SKAction.move(to: CGPoint(x: Boundry.position.x, y: Boundry.position.y + 1200), duration: 1.0), (SKAction.move(to: CGPoint(x: Boundry.position.x + 300, y: Boundry.position.y + 1200), duration: 0.7))]))
        }
        if (timerR3 > R3rand)
        {
            timerR3 = 0.0
            R3rand = Double.random(in: 1 ... 5)
            rectangle3.run(SKAction.rotate(byAngle: 3.145926, duration: 0.7))

            rectangle3.run(SKAction.sequence([SKAction.move(to: CGPoint(x: Boundry.position.x, y: Boundry.position.y + 800), duration: 1.0), (SKAction.move(to: CGPoint(x: Boundry.position.x + 300, y: Boundry.position.y + 800), duration: 0.7))]))
        }
        if (timerR4 > R4rand)
        {
            timerR4 = 0.0
            R4rand = Double.random(in: 1 ... 5)
            rectangle4.run(SKAction.sequence([SKAction.move(to: CGPoint(x: Boundry.position.x, y: Boundry.position.y + 400), duration: 1.0), (SKAction.move(to: CGPoint(x: Boundry.position.x + 300, y: Boundry.position.y + 400), duration: 0.7))]))
        }
        
        
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?)
    {
        if (gamestate == 0)
        {
            
            pushup = true
            
        }
        else
        {
            let newScene = MainMenu(size: (self.view?.bounds.size)!)
            let transition = SKTransition.reveal(with: .down, duration: 2)
            self.view?.presentScene(newScene, transition: transition)
            
            transition.pausesOutgoingScene = false
            transition.pausesIncomingScene = false
            
        }
    }
    
    override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?)
    {
        pushup = false
    }
    
    func Createcam()
    {
        cameraNode = SKCameraNode()
        cameraNode.setScale(1)
        cameraNode.position = CGPoint(x: self.frame.midX, y: self.frame.midY)
        self.camera = cameraNode
        self.addChild(cameraNode)
        
    }
    
    func didBegin(_ contact: SKPhysicsContact)
    {
        if (gamestate == 0)
        {
            if (contact.bodyA.categoryBitMask | contact.bodyB.categoryBitMask == CategoryBitMask.Node1 | CategoryBitMask.obsticle)
            {
                print("node 1")
                kill = true
                gamestate = 2 //0 playing, 1 win, 2 loss
            }
            if (contact.bodyA.categoryBitMask | contact.bodyB.categoryBitMask == CategoryBitMask.Node1 | CategoryBitMask.boundry)
            {
                if ( distance(vector2( Float(Node1.position.x), Float(Node1.position.y )) , vector2( Float(roof.position.x ),Float( roof.position.y ))) < 500 )
                {
                    gamestate = 1
                }
            }
        }
        
    }
    
    
    func createNode1()
    {
        Node1.name = "one"
        Node1.fillColor = UIColor.blue
        Node1.position = CGPoint(x: self.frame.midX, y: self.frame.minY + 11)
        Node1.physicsBody = SKPhysicsBody(circleOfRadius: Node1.frame.width/2)
        Node1.physicsBody?.categoryBitMask = CategoryBitMask.Node1
        Node1.physicsBody?.contactTestBitMask = CategoryBitMask.boundry | CategoryBitMask.obsticle
        Node1.physicsBody?.collisionBitMask = CategoryBitMask.boundry | CategoryBitMask.obsticle
        
        addChild(Node1)
        
        node2 = SKShapeNode(rectOf: CGSize(width: 64, height: 64))
        node2.fillColor = SKColor.white
        node2.fillTexture = SKTexture(imageNamed: "doge")
        Node1.addChild(node2)
        
    }
    
    
    func createobsticle(_ number: Int)
    {
        if (number == 1)
        {
            rectangle1.name = "obsicle"
            rectangle1.color = UIColor.red
            rectangle1.size = CGSize(width: self.frame.width - 10, height: 10)
            rectangle1.position = CGPoint(x: Boundry.position.x + 300, y: Boundry.position.y + 1600)
            rectangle1.physicsBody = SKPhysicsBody(rectangleOf: rectangle1.size)
            rectangle1.physicsBody?.isDynamic = false
            rectangle1.physicsBody?.categoryBitMask = CategoryBitMask.obsticle
            addChild(rectangle1)
        }
        
        if (number == 2)
        {
            rectangle2.name = "obsicle"
            rectangle2.color = UIColor.red
            rectangle2.size = CGSize(width: self.frame.width - 10, height: 10)
            rectangle2.position = CGPoint(x: Boundry.position.x + 300, y: Boundry.position.y + 1200)
            rectangle2.physicsBody = SKPhysicsBody(rectangleOf: rectangle2.size)
            rectangle2.physicsBody?.isDynamic = false
            rectangle2.physicsBody?.categoryBitMask = CategoryBitMask.obsticle
            addChild(rectangle2)
        }
        
        if (number == 3)
        {
            rectangle3.name = "obsicle"
            rectangle3.color = UIColor.red
            rectangle3.size = CGSize(width: self.frame.width - 10, height: 10)
            rectangle3.position = CGPoint(x: Boundry.position.x + 300, y: Boundry.position.y + 800)
            rectangle3.physicsBody = SKPhysicsBody(rectangleOf: rectangle3.size)
            rectangle3.physicsBody?.isDynamic = false
            rectangle3.physicsBody?.categoryBitMask = CategoryBitMask.obsticle
            addChild(rectangle3)
        }
        
        if (number == 4)
        {
            rectangle4.name = "obsicle"
            rectangle4.color = UIColor.red
            rectangle4.size = CGSize(width: self.frame.width - 10, height: 10)
            rectangle4.position = CGPoint(x: Boundry.position.x + 300, y: Boundry.position.y + 400)
            rectangle4.physicsBody = SKPhysicsBody(rectangleOf: rectangle4.size)
            rectangle4.physicsBody?.isDynamic = false
            rectangle4.physicsBody?.categoryBitMask = CategoryBitMask.obsticle
            addChild(rectangle4)
        }
        
    }
    
    func createlabel()
    {
        label = SKLabelNode()
        label.text = "this gets replaced with time"
        label.fontSize = 32.0
        if (UserDefaults.standard.integer(forKey: "Lighting") == 0) //lighting on (default)
        {
            label.fontColor = UIColor.white
        }
        else // lighting off
        {
            label.fontColor = UIColor.black
        }
        label.position = CGPoint(x:  0, y:  300 * cameraNode.yScale)
        cameraNode.addChild(label)
        
        
        
        label2 = SKLabelNode()
        label2.text = ""
        label2.fontSize = 32.0
        if (UserDefaults.standard.integer(forKey: "Lighting") == 0) //lighting on (default)
        {
            label2.fontColor = UIColor.white
        }
        else // lighting off
        {
            label2.fontColor = UIColor.black
        }
        label2.position = CGPoint(x: 0, y:  250 * cameraNode.yScale)
        cameraNode.addChild(label2)
    }
    
    func CreateTileMap()
    {
        tileMap = SKNode()
        addChild(tileMap)
        tileMap.setScale(CGFloat(1.0))
        
        let tileSet = SKTileSet(named: "bgTile")
        let tileSize = CGSize(width: 256, height: 256)
        let rockTile = tileSet?.tileGroups.first { $0.name == "Cobblestone" }
        
        let backgroundLayer = SKTileMapNode(tileSet: tileSet!, columns: 4 , rows: 20 , tileSize: tileSize)
        backgroundLayer.fill(with: rockTile)
        
        backgroundLayer.zPosition = -1
        
        if (UserDefaults.standard.integer(forKey: "Lighting") == 0) //lighting on (default)
        {
            backgroundLayer.lightingBitMask = 1
            
        }
        else // lighting off
        {
        }
        tileMap.addChild(backgroundLayer)
        
    }
    
    func Audio()
    {
        let audioNode = SKAudioNode(fileNamed: "foxxy dekay & 4649nadeshiko - 37564.mp3")
        audioNode.autoplayLooped = true
        self.addChild(audioNode)
        audioNode.run(SKAction.play())
        
    }
    
    func createLight()
    {
        light.categoryBitMask = 1
        light.falloff = 0.1
        light.ambientColor = UIColor(red: 0.1, green: 0.1, blue: 0.1, alpha: 1.0)
        light.lightColor = UIColor(red: 0.9, green: 0.9, blue: 0.9, alpha: 1.0)
        light.shadowColor = UIColor(red: 0.0, green: 0.0, blue: 0.0, alpha: 0.2)
        light.position = CGPoint(x: 0, y: 0)
        self.addChild(light)
        
    }
}

class MainMenu: SKScene
{
    
    var shapemenu = SKShapeNode()
    var label = SKLabelNode()
    var label2 = SKLabelNode()

    var particle = SKEmitterNode()
    
    override func didMove(to view: SKView)
    {
        createlabel("TheGame", vector2(Float(self.frame.midX), Float(self.frame.midY + 0)) , 0)
        createlabel("lighting is off -->", vector2(Float(self.frame.midX - 100), Float(self.frame.height - 100)) , 1)
        if (UserDefaults.standard.integer(forKey: "Lighting") == 0) //lighting on (default)
        {
            label2.text = "lighting is off (yes lag) -->"
        }
        else // lighting off
        {
            label2.text = "lighting is on (no lag) -->"
        }
        createshapemenu()
        let swipeUp = UISwipeGestureRecognizer(target: self, action: #selector(handleGesture))
        swipeUp.direction = .up
        self.view?.addGestureRecognizer(swipeUp)
    }
    @objc func handleGesture(gesture: UISwipeGestureRecognizer) -> Void
    {
        if gesture.direction == .up
        {
            createEmitter()
        }
    }

    
    func createshapemenu()
    {
        shapemenu = SKShapeNode(rectOf: CGSize(width: 100, height: 100))
        shapemenu.fillColor = SKColor.white
        shapemenu.fillTexture = SKTexture(imageNamed: "doge")
        shapemenu.position = CGPoint(x: self.frame.width - 100, y: self.frame.height - 100)
        self.addChild(shapemenu)
        
    }
    
    func createlabel(_ text:String, _ vec2: vector_float2, _ type: Int)
    {
        if (type == 0 )
        {
            label = SKLabelNode()
            label.text = text
            label.fontSize = 32.0
            label.fontColor = UIColor.white
            label.position = CGPoint(x: CGFloat(vec2.x) , y: CGFloat(vec2.y))
            self.addChild(label)
        }
        if (type == 1)
        {
            label2 = SKLabelNode()
            label2.text = text
            label2.fontSize = 20.0
            label2.fontColor = UIColor.white
            label2.position = CGPoint(x: CGFloat(vec2.x) , y: CGFloat(vec2.y))
            self.addChild(label2)
        }
 
    }
    
    func createEmitter()
    {
        particle = SKEmitterNode()
        particle.particleTexture = SKTexture(imageNamed: "doge")
        particle.particleSize = CGSize(width: 32, height: 32)
        particle.particleBirthRate = 10
        particle.numParticlesToEmit = Int.max
        particle.particleLifetime = 15
        particle.particleLifetimeRange = 0.0
        particle.position = CGPoint(x: self.frame.midX, y: self.frame.minY)
        particle.particlePositionRange = CGVector(dx: self.frame.width/2, dy: 0)
        particle.particleSpeed = 200
        particle.particleSpeedRange = 60
        particle.emissionAngle = 3.1415926535/2
        particle.emissionAngleRange = 3.14159265358979/10
        particle.particleScale = 1
        particle.particleScaleRange = 0.9
        particle.particleRotation = 0
        particle.particleRotationRange = 3.14159265358979/2
        
        self.addChild(particle)
        
    }
    
    override func update(_ currentTime: TimeInterval)
    {
        particle.particleColorSequence = nil
        particle.particleColorBlendFactor = 1
        let red = Int.random(in: 0...256)
        let green = Int.random(in: 0...256)
        let blue = Int.random(in: 0...256)
        particle.particleColor = UIColor(red: CGFloat(red)/256, green: CGFloat(green)/256, blue: CGFloat(blue)/256, alpha: 1)
        
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?)
    {
        let location = touches.first?.location(in: self)
        if label.contains(location!)
        {
            let newScene = level(size: (self.view?.bounds.size)!)
            let transition = SKTransition.reveal(with: .down, duration: 2)
            self.view?.presentScene(newScene, transition: transition)
            
            transition.pausesOutgoingScene = false
            transition.pausesIncomingScene = false
        }
        if (shapemenu.contains(location!))
        {
            if (UserDefaults.standard.integer(forKey: "Lighting") == 0) //lighting on (default)
            {
                UserDefaults.standard.set(1, forKey: "Lighting")
                label2.text = "lighting is off (no lag) -->"
            }
            else // lighting off
            {
                UserDefaults.standard.set(0, forKey: "Lighting")
                label2.text = "lighting is on (yes lag) -->"
            }
            
        }
    }
}

class level: SKScene
{
    var shapemenu = SKShapeNode()
    var label = SKLabelNode()
    var label2 = SKLabelNode()

    
    
    override func didMove(to view: SKView)
    {
        createlabel("level 1", vector2(Float(self.frame.midX), Float(self.frame.midY + 100)))
        createlabel2("level 2", vector2(Float(self.frame.midX), Float(self.frame.midY - 100)))

    }
    

    func createlabel(_ text:String, _ vec2: vector_float2)
    {
        label = SKLabelNode()
        label.text = text
        label.fontSize = 32.0
        label.fontColor = UIColor.white
        label.position = CGPoint(x: CGFloat(vec2.x) , y: CGFloat(vec2.y))
        self.addChild(label)
    }
    
    func createlabel2(_ text:String, _ vec2: vector_float2)
    {
        label2 = SKLabelNode()
        label2.text = text
        label2.fontSize = 32.0
        label2.fontColor = UIColor.white
        label2.position = CGPoint(x: CGFloat(vec2.x) , y: CGFloat(vec2.y))
        self.addChild(label2)
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?)
    {
        let location = touches.first?.location(in: self)
        if label.contains(location!)
        {
            let newScene = GameScene1(size: (self.view?.bounds.size)!)
            let transistion = SKTransition.reveal(with: .up, duration: 2)
            self.view?.presentScene(newScene, transition:  transistion)
            transistion.pausesIncomingScene = false
            transistion.pausesOutgoingScene = true
        }
        
        if label2.contains(location!)
        {
            let newScene = GameScene2(size: (self.view?.bounds.size)!)
            let transistion = SKTransition.reveal(with: .up, duration: 2)
            self.view?.presentScene(newScene, transition:  transistion)
            transistion.pausesIncomingScene = false
            transistion.pausesOutgoingScene = true
        }
    }
    
}
